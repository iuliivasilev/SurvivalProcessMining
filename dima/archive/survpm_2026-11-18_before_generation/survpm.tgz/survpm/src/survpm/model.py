"""Модель: сеть состояний с вероятностями выбора, временами переходов и цензурой."""
import numpy as np
import pandas as pd

from . import adapters, covariates, features
from .curves import completion_cdf, curves_table, residual_cdf
from .distributions import CANDIDATE_FAMILIES, dist_str, mean_time, scipy_args, select_families
from .estimation import estimate_network, source_nll
from .eventlog import EventLog
from .log import censoring_summary, intervals as make_intervals, prepare
from .simulation import completion_times, simulate
from .network import Network
from .models.transitions import ExponentialTransitionModel
from .process import ProcessModel


class CensoredStateNet:
    """Стохастическая сеть состояний, оцениваемая по журналу с правой цензурой.

    ``transition_mode="min_time"`` (по умолчанию) использует независимые
    экспоненциальные времена и выбирает минимальное. ``choice_then_time`` сохраняет
    прежнюю softmax/AFT модель. В min_time ``edges_`` описывает наблюдаемое ядро:
    p = lambda/sum(lambda), время до победителя ~ Exp(sum(lambda)); интенсивности
    конкурирующих причин доступны в ``transitions_.rates``.

    ``use_censoring=False`` — наивная оценка только по завершённым интервалам.
    ``families`` — словарь ``(src, dst) → семейство``; если не задан, выбирается по AIC
    из ``candidates``. ``repeats`` — что делать с повторами состояния подряд, см. :func:`prepare`
    (``"collapse"`` воспроизводит результаты до 28.10.2026).

    ``feature_columns`` включает log-rate регрессию в min_time или softmax/AFT
    в choice_then_time по признакам на входе в состояние.
    Для обучения передайте EventLog или ``fit(intervals=..., X=...)``. ``feature_window``
    задаёт окно для счётчиков замеров; ``l2`` — штраф коэффициентов признаков.

    Пример::

        model = CensoredStateNet("Registration", "Discharge").fit(raw)
        model.edges_table()
        model.survival([1, 7, 30])
    """

    def __init__(self, start=None, terminal=None, use_censoring=True, families=None, candidates=CANDIDATE_FAMILIES,
                 min_duration=1 / 1440, repeats="simultaneous", *, feature_columns=None, feature_window=None, l2=1., transition_mode="min_time"):
        if transition_mode not in ('min_time', 'choice_then_time'):
            raise ValueError('transition_mode: min_time или choice_then_time')
        self.transition_mode = transition_mode
        self.start, self.terminal, self.repeats = start, terminal, repeats
        self.use_censoring, self.families = use_censoring, families
        self.candidates, self.min_duration = candidates, min_duration
        self.feature_columns = list(feature_columns) if feature_columns else []
        reserved = {"case_id", "src", "dst", "duration", "observed", "reason", "enter"}.intersection(self.feature_columns)
        if reserved:
            raise ValueError(f"Имена признаков совпадают с полями интервалов: {sorted(reserved)}")
        self.feature_window, self.l2 = feature_window, l2
        if l2 < 0:
            raise ValueError("l2 должен быть неотрицательным")

    def fit(self, raw=None, observation_end=None, reason="lost", *, intervals=None, X=None):
        """Оценка по журналу ``raw`` (``case_id, activity, timestamp`` или :class:`EventLog`)
        или по готовым интервалам. У ``EventLog`` по умолчанию ``observation_end = raw.last_seen``.

        ``observation_end`` — момент окончания наблюдения незавершённых трасс (Series по ``case_id``);
        без него цензура наступает в момент последней записи трассы. ``reason`` — причина цензуры
        (строка или Series по ``case_id``).

        При ``feature_columns`` признаки извлекаются из EventLog на входе; готовый X
        должен содержать выбранные колонки и иметь тот же индекс, что интервалы.
        """
        event_log = raw if isinstance(raw, EventLog) else None
        self._bounds_from(event_log)
        if isinstance(raw, EventLog):
            seen = raw.last_seen if observation_end is None else \
                pd.concat([raw.last_seen, observation_end], axis=1).max(axis=1)
            raw, observation_end = raw.events, seen
        log, cases = None, None
        if intervals is None:
            log, cases = prepare(raw, self.start, self.terminal, observation_end, reason, self.repeats)
            intervals = make_intervals(log, cases, self.min_duration)
        if self.feature_columns:
            frame = self._feature_frame(intervals, event_log, X)
            self.encoder_ = covariates.FeatureEncoder().fit(frame)
            design = self.encoder_.transform(frame)
            intervals = intervals.copy()
            intervals[self.feature_columns] = frame
        self.intervals_ = intervals
        if self.transition_mode == 'min_time':
            if any(f != 'exponential' for f in (self.families or {}).values()) or 'exponential' not in self.candidates:
                raise NotImplementedError('min_time пока поддерживает только exponential')
            self.network_ = Network.from_edges(intervals.loc[intervals.observed, ['src', 'dst']],
                                              [self.start], [self.terminal])
            selected = intervals if self.use_censoring else intervals.loc[intervals.observed]
            frame = self._feature_frame(intervals, event_log, X) if self.feature_columns else None
            self.transitions_ = ExponentialTransitionModel(l2=self.l2).fit(
                selected, self.network_, frame.loc[selected.index] if frame is not None else None)
            self.process_model_ = ProcessModel(self.network_, self.transitions_)
            self.encoder_ = self.transitions_.encoder
            self.edges_ = self.transitions_.winner_edges()
            self.diagnostics_ = self.transitions_.diagnostics
            self.families_ = {edge: 'exponential' for edge in self.transitions_.rates}
            self.aic_table_ = pd.DataFrame()
            self.stop_ = censoring_summary(intervals).set_index('src')['q_censored'].to_dict()
            self.log_, self.cases_ = log, cases
            return self
        self.families_, self.aic_table_ = select_families(intervals, self.candidates)
        if self.families:
            self.families_.update(self.families)
        if self.feature_columns:
            rows, diagnostics = [], []
            for _, positions in intervals.groupby("src", sort=True).indices.items():
                edges, diagnostic = covariates.fit_source(intervals.iloc[positions], self.families_,
                                                          design[positions], self.use_censoring, self.l2)
                rows.extend(edges)
                diagnostics.append(diagnostic)
            self.edges_, self.diagnostics_ = rows, pd.DataFrame(diagnostics)
        else:
            self.edges_, self.diagnostics_ = estimate_network(intervals, self.families_, self.use_censoring)
        self.stop_ = censoring_summary(intervals).set_index("src")["q_censored"].to_dict()
        self.log_, self.cases_ = log, cases
        return self

    def _bounds_from(self, log):
        """START/TERMINAL из ``log.rules``, если они не заданы в конструкторе."""
        if self.start is not None and self.terminal is not None:
            return
        from .eventlog import process_bounds
        if log is None:
            raise ValueError("Задайте start/terminal или передайте EventLog после prepare(rules)")
        starts, terminals = process_bounds(log, self.start, self.terminal)
        self.start = starts[0] if len(starts) == 1 else starts
        self.terminal = terminals[0] if len(terminals) == 1 else terminals

    def _feature_frame(self, intervals, log=None, X=None):
        if X is not None:
            if not X.index.equals(intervals.index):
                raise ValueError("Индекс X должен совпадать с индексом intervals")
            frame = X
        elif all(c in intervals for c in self.feature_columns):
            frame = intervals
        else:
            frame = features.at_entry(intervals, log, window=self.feature_window) if log is not None else pd.DataFrame(index=intervals.index)
            frame["history_visits"] = intervals.groupby(["case_id", "src"], sort=False).cumcount() + 1
            frame["history_elapsed_days"] = (intervals["enter"] - intervals.groupby("case_id")["enter"].transform("min")) / pd.Timedelta(days=1)
        missing = set(self.feature_columns) - set(frame.columns)
        if missing:
            raise ValueError(f"Нужен EventLog или X с признаками: {sorted(missing)}")
        return frame[self.feature_columns].copy()

    def _require_profile(self):
        if self.feature_columns:
            raise ValueError("Для прогноза задайте профиль: model.for_features({...})")

    def for_features(self, values):
        """Модель сценария с фиксированным профилем во всех будущих состояниях.

        Возвращает копию; будущие анализы и история автоматически не обновляются.
        ``values`` — словарь всех выбранных признаков в исходных единицах.
        """
        from copy import copy
        if not self.feature_columns:
            return copy(self)
        design = self.encoder_.transform(pd.DataFrame([values]))
        result = copy(self)
        if self.transition_mode == 'min_time':
            result.transitions_ = self.transitions_.condition(values)
            result.edges_ = result.transitions_.winner_edges()
            result.process_model_ = ProcessModel(self.network_, result.transitions_)
            result.feature_columns = []
            return result
        result.edges_ = covariates.condition_edges(self.edges_, design)
        result.feature_columns = []
        return result

    def coefficients_table(self):
        """Коэффициенты softmax и AFT для стандартизованных закодированных признаков."""
        if self.transition_mode == 'min_time':
            names = self.encoder_.names_ if self.encoder_ is not None else []
            return pd.DataFrame([dict(transition=f'{src}→{dst}', feature=f, rate=b)
                                 for (src, dst), coef in self.transitions_.coefficients.items()
                                 for f, b in zip(names, coef)], columns=['transition', 'feature', 'rate'])
        return pd.DataFrame([dict(transition=e["name"], feature=f, choice=b, time=g)
                             for e in self.edges_ for f, b, g in
                             zip(self.encoder_.names_, e["choice_coef"], e["time_coef"])])

    def edges_table(self):
        """Оценённые переходы: вероятность выбора, распределение, среднее, медиана, 90% квантиль."""
        self._require_profile()
        rows = []
        for edge in self.edges_:
            rv, args, kwargs = scipy_args(edge["dist"])
            rows.append(dict(transition=edge["name"], src=edge["src"], dst=edge["dst"], p=edge["p"],
                             distribution=dist_str(edge["dist"]), n_completed=edge["n_completed"],
                             mean_days=mean_time(edge["dist"]), median_days=rv.median(*args, **kwargs),
                             q90_days=rv.ppf(.9, *args, **kwargs)))
        return pd.DataFrame(rows)

    def repeat_table(self):
        """Вероятность повтора для каждого состояния (по вероятностям выбора, без времени и цензуры).

        ``p_immediate`` — следующее состояние то же самое (петля ``s → s``);
        ``p_return`` — состояние ещё встретится до ``terminal`` (сразу или через другие);
        ``expected_visits`` — среднее число заходов при одном заходе на старте, ``1 / (1 − p_return)``.
        """
        self._require_profile()
        states = sorted({e["src"] for e in self.edges_} | {e["dst"] for e in self.edges_})
        index = {s: i for i, s in enumerate(states)}
        P = np.zeros((len(states), len(states)))
        for e in self.edges_:
            if e["src"] != self.terminal:
                P[index[e["src"]], index[e["dst"]]] += e["p"]
        P /= np.where(P.sum(1, keepdims=True) > 0, P.sum(1, keepdims=True), 1)
        rows = []
        for s in states:
            if s == self.terminal:
                continue
            i = index[s]
            # h[d] — вероятность из d попасть в s раньше, чем в terminal или тупик
            free = [j for j in range(len(states)) if j != i and states[j] != self.terminal]
            A = np.eye(len(free)) - P[np.ix_(free, free)]
            h = np.zeros(len(states))
            h[i] = 1.
            h[free] = np.linalg.solve(A, P[free, i])
            p_return = float(P[i] @ h)
            rows.append(dict(state=s, p_immediate=P[i, i], p_return=p_return,
                             expected_visits=1 / (1 - p_return) if p_return < 1 else np.inf))
        return pd.DataFrame(rows)

    def simulate(self, n, seed=None, censoring=False, horizon=None):
        """Трассы ``[(states, times), ...]``; ``censoring=True`` — обрыв с наблюдаемой вероятностью ``q``."""
        self._require_profile()
        if self.transition_mode == 'min_time' and hasattr(self, 'transitions_'):
            rng = np.random.default_rng(seed)
            traces = []
            for i in range(n):
                state, now, states, times = self.start, 0., [self.start], [0.]
                for _ in range(1000):
                    rates = self.transitions_.transition_parameters(state)
                    if state == self.terminal or not any(rates.values()):
                        break
                    if censoring and rng.random() < self.stop_.get(state, 0.):
                        break
                    dst, dt = self.process_model_.next_transition(state, {}, [], rng)
                    now += dt
                    if horizon is not None and now > horizon[i]:
                        break
                    state = dst
                    states.append(state)
                    times.append(now)
                traces.append((states, times))
            return traces
        return simulate(self.edges_, self.start, self.terminal, n, seed,
                        stop=self.stop_ if censoring else None, horizon=horizon)

    def completion_times(self, n=10_000, seed=0):
        """Время от ``start`` до ``terminal`` по симуляции без цензуры; ``inf`` — не дошла."""
        return completion_times(self.simulate(n, seed), self.terminal)

    def survival(self, t, n=10_000, seed=0, method="sim", step=None):
        """``S(t) = P(T > t)`` для времени до ``terminal``.

        ``method="sim"`` — доля из ``n`` симулированных трасс; ``method="grid"`` — свёртка со
        сдвигом на сетке с шагом ``step`` дней (по умолчанию ``max(t) / 2000``), без случайности.
        """
        t = np.asarray(t, dtype=float)
        if method == "grid":
            times, states, F = self._grid(t.max(), step)
            return 1 - np.interp(t, times, F[states.index(self.start)])
        if method != "sim":
            raise ValueError(method)
        times = np.sort(self.completion_times(n, seed))
        return 1 - np.searchsorted(times, t, side="right") / len(times)

    def _grid(self, horizon, step=None):
        self._require_profile()
        return completion_cdf(self.edges_, self.terminal, horizon, step or horizon / 2000)

    def state_curves(self, horizon, step=None):
        """Кривые «из текущего места»: для каждого состояния ``s`` — ``F_s(t)`` и ``S_s(t)``,
        время от входа в ``s`` до ``terminal`` (таблица ``state, time_days, cdf, survival``)."""
        return curves_table(*self._grid(horizon, step))

    def residual_survival(self, state, elapsed, t, step=None):
        """``S(t | s, a)`` — остаток времени до ``terminal`` для идущего случая, который уже
        ``elapsed`` дней находится в ``state``; ``t`` отсчитывается от текущего момента."""
        t = np.asarray(t, dtype=float)
        times, states, F = self._grid(t.max(), step)
        return 1 - np.interp(t, times, residual_cdf(self.edges_, state, elapsed, times, states, F))

    def nll(self, intervals, X=None):
        """−log L интервалов с цензурой. Трассы с переходом или состоянием, которых нет в модели,
        исключаются; их доля — ``unseen_share``."""
        edges = {(e["src"], e["dst"]): e for e in self.edges_}
        sources = {e["src"] for e in self.edges_}
        observed = intervals["observed"]
        known = pd.Series([(s, d) in edges for s, d in zip(intervals["src"], intervals["dst"])], index=intervals.index)
        unseen = (observed & ~known) | (~observed & ~intervals["src"].isin(sources))
        unseen_cases = set(intervals.loc[unseen, "case_id"])
        kept = intervals.loc[~intervals["case_id"].isin(unseen_cases)]
        if self.transition_mode == 'min_time':
            frame = self._feature_frame(intervals, X=X).loc[kept.index] if self.feature_columns else None
            value = -self.transitions_.log_likelihood(kept, frame)
            return dict(unseen_share=len(unseen_cases)/intervals.case_id.nunique(),
                        nll_per_interval=value/len(kept) if len(kept) else np.nan,
                        nll_per_trace=value/kept.case_id.nunique() if len(kept) else np.nan)
        if self.feature_columns:
            design = self.encoder_.transform(self._feature_frame(intervals, X=X))
        nll = 0.
        for src, group in kept.groupby("src"):
            out = [edge for edge in edges if edge[0] == src]
            if self.feature_columns:
                positions = np.flatnonzero((intervals.src == src) & ~intervals.case_id.isin(unseen_cases))
                nll += covariates.conditional_nll(group, [edges[e] for e in out], design[positions])
            else:
                nll += source_nll(group, out, [edges[e]["p"] for e in out], [edges[e]["dist"] for e in out])
        return dict(unseen_share=len(unseen_cases) / intervals["case_id"].nunique(),
                    nll_per_interval=nll / len(kept) if len(kept) else np.nan,
                    nll_per_trace=nll / kept["case_id"].nunique() if len(kept) else np.nan)

    def score(self, intervals, X=None):
        """Средний log L на интервал (больше — лучше), как ``score`` в sklearn."""
        return -self.nll(intervals, X=X)["nll_per_interval"]

    def evaluate(self, raw, metrics="level4", observation_end=None, reason="lost", *, n_sim=5000, seed=2026):
        """Метрики обученной модели на журнале ``raw`` (DataFrame или :class:`EventLog`).

        ``metrics`` — имя, список имён, ``"level1"`` … ``"level4"`` или ``"all"``.
        По умолчанию — NLL и доля неизвестных трасс, без дополнительных зависимостей.
        Возвращает ``{уровень: DataFrame}``, без переобучения и кросс-валидации.
        Уровень 1 оценивает только эту сеть, без сравнения с Inductive Miner.
        ``ibs`` и ``temporal_deviation_share`` требуют обучения через ``fit(raw)``,
        чтобы сохранить обучающий журнал и таблицу исходов. Остальные метрики доступны
        и после ``fit(intervals=...)``. ``n_sim`` и ``seed`` управляют симуляцией для метрик.
        """
        from .metrics.fold import Fold
        from .metrics.registry import LEVEL_OF, METRICS, _expand

        if not hasattr(self, "edges_"):
            raise ValueError("Сначала обучите модель: fit(raw) или fit(intervals=...)")
        names = [metrics] if isinstance(metrics, str) else list(metrics)
        selected = dict.fromkeys(metric for name in names for metric in _expand(name))
        if not selected:
            raise ValueError("Метрики не выбраны: укажите имя, уровень или 'all'")
        if self.feature_columns and any(LEVEL_OF[name] != "level4" for name in selected):
            raise ValueError("Для модели с признаками доступны метрики level4; для сценарных метрик используйте for_features({...}).evaluate(...)")
        needs_training = {"ibs", "temporal_deviation_share"}.intersection(selected)
        if needs_training and self.log_ is None:
            raise ValueError(f"Метрики {', '.join(sorted(needs_training))} требуют fit(raw), а не fit(intervals=...)")
        event_log = raw if isinstance(raw, EventLog) else None
        if isinstance(raw, EventLog):
            seen = raw.last_seen if observation_end is None else \
                pd.concat([raw.last_seen, observation_end], axis=1).max(axis=1)
            raw, observation_end = raw.events, seen
        log, cases = prepare(raw, self.start, self.terminal, observation_end, reason, self.repeats)
        test_intervals = make_intervals(log, cases, self.min_duration)
        if self.feature_columns:
            test_intervals[self.feature_columns] = self._feature_frame(test_intervals, event_log)
        fold = Fold(0, seed, n_sim, {"model": self}, self.log_, log, self.cases_, cases,
                    self.intervals_, test_intervals)
        if any(LEVEL_OF[name] == "level1" for name in selected):
            # Метрики process переиспользуют сеть; сравнение с Inductive Miner остаётся в CV.
            fold.cache["level1_nets"] = {"model": self.to_pm4py(censoring=False)}
        tables = {}
        for name in selected:
            rows = tables.setdefault(LEVEL_OF[name], {})
            for row in METRICS[name](fold):
                rows.setdefault(row["model"], {}).update(row)
        return {level: pd.DataFrame(list(rows.values())) for level, rows in tables.items()}

    def to_pm4py(self, censoring=True):
        """``(net, initial_marking, final_marking)`` PM4Py; ``censoring=False`` — без места ``CENS``."""
        self._require_profile()
        intervals = self.intervals_ if censoring else self.intervals_.loc[self.intervals_["observed"]]
        return adapters.state_petri_net(intervals, self.start, self.terminal, self.edges_)

    def to_sdfa(self, censoring=False, digits=3):
        """Автомат для Ebi; ``censoring=True`` — остановка в состоянии с вероятностью ``q``."""
        self._require_profile()
        return adapters.to_sdfa(self.edges_, self.start, self.stop_ if censoring else None, digits)
